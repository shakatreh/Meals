package com.coding.meal.food.domain

data class Food(
    val id : String,
    val name : String,
    val image : String,
)
