package com.coding.meal.core.domain

interface Error