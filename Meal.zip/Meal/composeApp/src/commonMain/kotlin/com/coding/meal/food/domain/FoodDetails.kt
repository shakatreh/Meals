package com.coding.meal.food.domain

data class FoodDetails(
    val name: String="",
    val area: String="",
    val instruction: String="",
    val image: String=""
)